import UIKit

var str = "Hello, playground"
