//
//  ViewController.swift
//  RETO HAMBURGUESAS
//
//  Created by Dilan Daniel Sandoval Berrueco on 04/05/19.
//  Copyright © 2019 Dilan Daniel Sandoval Berrueco. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TuHamburguesa: UILabel!
    @IBOutlet weak var TuPais: UILabel!
    let colores = Crayola()
    let paises = PaisesDelMundo()
    let hamburguesas = HamburguesasDelMundo()
    override func viewDidLoad() {
        super.viewDidLoad()
        func viewDidLoad() {
    }
}
    
    @IBAction func Boton() {
        let colorAleatorio = colores.regresaColorAleatorio();
        TuPais.text = paises.regresaPaisAleatorio();
        TuHamburguesa.text = hamburguesas.regresaHamburguesaAleatoria();
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
        
    }
    
}
