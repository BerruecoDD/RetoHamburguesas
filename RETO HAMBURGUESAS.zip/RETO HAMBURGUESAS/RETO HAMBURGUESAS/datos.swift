//
//  datos.swift
//  RETO HAMBURGUESAS
//
//  Created by Dilan Daniel Sandoval Berrueco on 04/05/19.
//  Copyright © 2019 Dilan Daniel Sandoval Berrueco. All rights reserved.
//

import UIKit
import Foundation

struct PaisesDelMundo {
    let paises = ["México","Alemania","Estados Unidos","Colombia","Francia","Inglaterra","Rusia","Italia","Rumania","Egipto","China","Japón","Ecuador","Irlanda","Mónaco","Nigeria","Perú","Suecia","Suiza","Dinamarca"]
    func regresaPaisAleatorio() -> String {
        let posicion = Int( arc4random()) % paises.count
        return paises[posicion]
    }
}


struct HamburguesasDelMundo {
    let tipoHamburguesa = ["Con tocino","Con aguacate","sin verdura","Hawaiana","Italiana","Con papas","Vegetariana","Con camaron","De pollo","Sin queso","Doble queso","Dos pisos","Doble carne","Con helado","Sin papas","Con chile","BBQ","Cajita feliz","Doble cebolla","Con aros de cebolla"]
    func regresaHamburguesaAleatoria() -> String {
        let posicion = Int( arc4random()) % tipoHamburguesa.count
        return tipoHamburguesa[posicion]
    }
}


struct Crayola {
    let Colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    func regresaColorAleatorio() -> UIColor {
        let posicion = Int( arc4random()) % Colores.count
        return Colores[posicion]
    }
}
